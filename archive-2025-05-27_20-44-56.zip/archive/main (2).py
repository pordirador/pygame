import pygame
import random
import sqlite3

# Инициализация Pygame
pygame.init()

# Константы
WIDTH, HEIGHT = 800, 600
FPS = 60
ANT_SIZE = 50
GRASS_SPEED = 5  # Скорость движения травы
BOMB_SIZE = 30
HEALTH_DECREASE = 10  # Сколько здоровья отнимает бомба
HEALTH_INCREASE = 20  # Сколько здоровья восстанавливает нектар
MAX_BOMBS = 5  # Максимальное количество бомб на экране
MAX_NECTAR = 3  # Максимальное количество нектара на экране

# Цвета
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

# Настройка экрана
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ant Runner")

# Загрузка изображения муравья, травы и бомб
ant_image = pygame.image.load("ant.png").convert_alpha()  # Путь к изображению муравья
grass_image = pygame.image.load("grass.png").convert_alpha()  # Путь к изображению травы
bomb_image = pygame.image.load("bomb.png").convert_alpha()  # Путь к изображению бомбочки
explosion_image = pygame.image.load(
    "explosion.png").convert_alpha()  # Путь к изображению взрыва (можно использовать спрайт или анимацию)


# Подключение к базе данных SQLite
def init_db():
    conn = sqlite3.connect("records.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            score INTEGER,
            speed INTEGER
        )
    """)
    cursor.execute("PRAGMA table_info(records)")
    columns = [col[1] for col in cursor.fetchall()]
    if "speed" not in columns:
        cursor.execute("ALTER TABLE records ADD COLUMN speed INTEGER DEFAULT 1")
    conn.commit()
    return conn


def draw_menu():
    screen.fill(BLACK)
    font = pygame.font.Font(None, 74)
    title_text = font.render("Ant Runner", True, WHITE)
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 100))

    font = pygame.font.Font(None, 50)
    start_text = font.render("Press SPACE to Start", True, WHITE)
    screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, 250))

    records_text = font.render("Press R to View Records", True, WHITE)
    screen.blit(records_text, (WIDTH // 2 - records_text.get_width() // 2, 300))

    help_text = font.render("Press F1 for Help", True, WHITE)
    screen.blit(help_text, (WIDTH // 2 - help_text.get_width() // 2, 350))

    exit_text = font.render("Press ESC to Exit", True, WHITE)
    screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, 400))

    pygame.display.flip()


def draw_pause():
    screen.fill(BLACK)
    font = pygame.font.Font(None, 74)
    pause_text = font.render("Paused", True, WHITE)
    screen.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2 - 50))

    font = pygame.font.Font(None, 50)
    help_text = font.render("Press F1 for Help", True, WHITE)
    screen.blit(help_text, (WIDTH // 2 - help_text.get_width() // 2, HEIGHT // 2 + 50))

    exit_text = font.render("Press ESC to Exit", True, WHITE)
    screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 100))

    pygame.display.flip()


def draw_help():
    screen.fill(BLACK)
    font = pygame.font.Font(None, 50)
    help_text = [
        "Controls:",
        "Left Arrow - Move Left",
        "Right Arrow - Move Right",
        "LShift - Increase Speed",
        "LCtrl - Decrease Speed",
        "P - Pause",
        "F1 - Help",
        "ESC - Exit to Menu"
    ]

    y_offset = 100
    for line in help_text:
        text = font.render(line, True, WHITE)
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, y_offset))
        y_offset += 50

    back_text = font.render("Press ESC to go back", True, WHITE)
    screen.blit(back_text, (WIDTH // 2 - back_text.get_width() // 2, y_offset + 50))

    pygame.display.flip()


def show_records():
    screen.fill(BLACK)
    font = pygame.font.Font(None, 50)
    records = conn.cursor().execute("SELECT score, speed FROM records ORDER BY score DESC LIMIT 10").fetchall()
    title_text = font.render("Top Records", True, WHITE)
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 50))

    y_offset = 150
    for idx, (score, speed) in enumerate(records):
        record_text = font.render(f"{idx + 1}. Score: {score}, Speed: {speed:.1f}", True, WHITE)
        screen.blit(record_text, (WIDTH // 2 - record_text.get_width() // 2, y_offset))
        y_offset += 50

    back_text = font.render("Press ESC to go back", True, WHITE)
    screen.blit(back_text, (WIDTH // 2 - back_text.get_width() // 2, y_offset + 50))

    pygame.display.flip()


def save_record(conn, score, speed):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO records (score, speed) VALUES (?, ?)", (score, speed))
    conn.commit()


def get_best_record(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT MAX(score) FROM records")
    result = cursor.fetchone()
    return result[0] if result[0] is not None else 0


def get_best_speed(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT speed FROM records WHERE score = (SELECT MAX(score) FROM records)")
    result = cursor.fetchone()
    return result[0] if result and result[0] is not None else 0


conn = init_db()


# Класс муравья
class Ant(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(ant_image, (ANT_SIZE, ANT_SIZE))
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH // 2, HEIGHT - 100)
        self.speed = 5
        self.health = 100  # Здоровье муравья

    def update(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def take_damage(self, damage):
        self.health -= damage
        if self.health < 0:
            self.health = 0

    def heal(self, amount):
        self.health += amount
        if self.health > 100:
            self.health = 100


# Класс ракеты (бомбы)
class Bomb(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(bomb_image, (BOMB_SIZE, BOMB_SIZE))
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WIDTH - self.rect.width)
        self.rect.y = random.randint(-100, -40)
        self.speed = random.randint(4, 8)

    def update(self):
        self.rect.y += self.speed * game_speed
        if self.rect.top > HEIGHT:
            self.rect.x = random.randint(0, WIDTH - self.rect.width)
            self.rect.y = random.randint(-100, -40)
            self.speed = random.randint(4, 8)


# Класс взрыва
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.transform.scale(explosion_image, (50, 50))  # Установим размер взрыва
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.life_time = 0  # Время жизни взрыва

    def update(self):
        self.life_time += 1
        if self.life_time > 10:  # После 10 кадров взрыв исчезает
            self.kill()


# Класс капли нектара
class Nectar(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, WIDTH - self.rect.width)
        self.rect.y = random.randint(-100, -40)
        self.speed = 3

    def update(self):
        self.rect.y += self.speed * game_speed
        if self.rect.top > HEIGHT:
            self.rect.x = random.randint(0, WIDTH - self.rect.width)
            self.rect.y = random.randint(-100, -40)


# Класс травы на фоне
class Grass(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.transform.scale(grass_image, (WIDTH, 50))  # Подгоняем размер под экран
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = HEIGHT - 50  # Трава будет на нижней части экрана

    def update(self):
        self.rect.x -= GRASS_SPEED * game_speed
        if self.rect.right < WIDTH:
            self.rect.left = 0


# Инициализация спрайтов
all_sprites = pygame.sprite.Group()
bombs = pygame.sprite.Group()
nectar_drops = pygame.sprite.Group()
grass = pygame.sprite.Group()
explosions = pygame.sprite.Group()

ant = Ant()
all_sprites.add(ant)

for _ in range(MAX_BOMBS):
    bomb = Bomb()
    all_sprites.add(bomb)
    bombs.add(bomb)

for _ in range(MAX_NECTAR):
    nectar = Nectar()
    all_sprites.add(nectar)
    nectar_drops.add(nectar)

# Добавляем траву на фон
for _ in range(2):  # Два слоя травы
    grass_sprite = Grass()
    all_sprites.add(grass_sprite)
    grass.add(grass_sprite)


# Основной игровой цикл
def main():
    global game_speed
    clock = pygame.time.Clock()
    running = True
    in_menu = True
    in_records = False
    in_help = False
    paused = False
    score = 0
    game_speed = 1
    best_score = get_best_record(conn)
    best_speed = get_best_speed(conn)

    start_ticks = pygame.time.get_ticks()  # Начальное время игры

    while running:
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        if in_menu:
            draw_menu()
            if keys[pygame.K_SPACE]:
                in_menu = False
            if keys[pygame.K_r]:
                in_records = True
                in_menu = False
            if keys[pygame.K_ESCAPE]:
                running = False
            if keys[pygame.K_F1]:
                in_help = True
                in_menu = False
        elif in_records:
            show_records()
            if keys[pygame.K_ESCAPE]:
                in_records = False
                in_menu = True
        elif in_help:
            draw_help()
            if keys[pygame.K_ESCAPE]:
                in_help = False
                if paused:
                    paused = False
                elif in_menu:
                    in_menu = True
        else:
            if keys[pygame.K_p]:
                paused = not paused
            if paused:
                draw_pause()
                if keys[pygame.K_F1]:
                    in_help = True
                    paused = False
                if keys[pygame.K_ESCAPE]:
                    running = False
            else:
                if keys[pygame.K_F1]:
                    in_help = True
                    paused = True

                if not in_help:
                    # Управление скоростью
                    if keys[pygame.K_LSHIFT]:
                        game_speed = min(game_speed + 0.1, 3)
                    if keys[pygame.K_LCTRL]:
                        game_speed = max(game_speed - 0.1, 0.5)

                    # Добавляем новые объекты, если их меньше чем нужно
                    if len(bombs) < MAX_BOMBS:
                        new_bomb = Bomb()
                        all_sprites.add(new_bomb)
                        bombs.add(new_bomb)

                    if len(nectar_drops) < MAX_NECTAR:
                        new_nectar = Nectar()
                        all_sprites.add(new_nectar)
                        nectar_drops.add(new_nectar)

                    # Обновление
                    for sprite in all_sprites:
                        if isinstance(sprite, Ant):
                            sprite.update(keys)  # Для муравья передаем keys
                        else:
                            sprite.update()  # Для остальных спрайтов не передаем keys

                    # Проверка столкновений
                    collided_bombs = pygame.sprite.spritecollide(ant, bombs, False)
                    for bomb in collided_bombs:
                        ant.take_damage(HEALTH_DECREASE)  # Уменьшаем здоровье муравья при столкновении с бомбой
                        bomb.kill()  # Удаляем бомбу с экрана
                        explosion = Explosion(bomb.rect.centerx, bomb.rect.centery)  # Создаем взрыв в месте столкновения
                        all_sprites.add(explosion)
                        explosions.add(explosion)

                    nectar_collected = pygame.sprite.spritecollide(ant, nectar_drops, True)
                    for nectar in nectar_collected:
                        ant.heal(HEALTH_INCREASE)  # Восстанавливаем здоровье при сборе нектара

                    # Если здоровье муравья равно нулю, завершаем игру
                    if ant.health <= 0:
                        save_record(conn, score, game_speed)
                        running = False

                    score += len(nectar_collected)

                    # Вычисляем прошедшее время
                    elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000  # Время в секундах

                    # Рендеринг
                    screen.fill(BLACK)
                    all_sprites.draw(screen)

                    # Отображение счёта, времени и здоровья
                    font = pygame.font.Font(None, 36)
                    score_text = font.render(f"Score: {score}", True, WHITE)
                    best_score_text = font.render(f"Best: {best_score} (Speed: {best_speed:.1f})", True, WHITE)
                    health_text = font.render(f"Health: {ant.health}", True, WHITE)
                    speed_text = font.render(f"Speed: {game_speed:.1f}", True, WHITE)
                    time_text = font.render(f"Time: {int(elapsed_time)}s", True, WHITE)  # Показываем время игры в секундах

                    screen.blit(score_text, (10, 10))
                    screen.blit(best_score_text, (10, 50))
                    screen.blit(health_text, (10, 90))
                    screen.blit(speed_text, (10, 130))
                    screen.blit(time_text, (WIDTH - 200, 10))  # Выводим время в верхний правый угол

                    pygame.display.flip()
                    clock.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()